# ==============================================================================
# 1. IMPORTS & PAGE CONFIG
# ==============================================================================
import streamlit as st
import os
import tempfile
import time
import json
import pandas as pd
import plotly.express as px
from datetime import datetime, timedelta
from dotenv import load_dotenv

# Media processing
from moviepy.editor import VideoFileClip, AudioFileClip
from yt_dlp import YoutubeDL
import whisper
from TTS.api import TTS
from pydub import AudioSegment

# Google Gemini
import google.generativeai as genai

# Language detection & translation
from langdetect import detect, LangDetectError
from googletrans import Translator

# Diarization
from pyannote.audio import Pipeline
import numpy as np
import librosa
import soundfile as sf

st.set_page_config(
    page_title="Traducteur Vidéo IA Multilingue",
    layout="wide",
    page_icon="🎬"
)

# ==============================================================================
# 2. LOAD API KEYS & INIT
# ==============================================================================
load_dotenv()
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
HF_TOKEN = os.getenv("HUGGINGFACE_TOKEN")

if not GEMINI_API_KEY:
    st.error("Clé API Gemini manquante ! Ajoutez GEMINI_API_KEY=VOTRE_CLE dans .env")
    st.stop()

try:
    genai.configure(api_key=GEMINI_API_KEY)
    model_gemini = genai.GenerativeModel("gemini-1.5-flash")
    translator = Translator()
except Exception as e:
    st.error(f"Erreur lors de la configuration de l'API : {e}")
    st.stop()

# Cache heavy models
@st.cache_resource
def get_whisper_model():
    return whisper.load_model("small")

@st.cache_resource
def get_diarization_pipeline(hf_token: str):
    return Pipeline.from_pretrained("pyannote/speaker-diarization-3.1", use_auth_token=hf_token)

# ==============================================================================
# 3. MULTILINGUAL PROCESSOR CLASS
# ==============================================================================
class MultilingualVideoProcessor:
    def __init__(self):
        self.languages = {
            'Français': 'fr', 'Anglais': 'en', 'Espagnol': 'es', 'Allemand': 'de',
            'Italien': 'it', 'Portugais': 'pt', 'Russe': 'ru', 'Chinois': 'zh',
            'Japonais': 'ja', 'Arabe': 'ar', 'Hindi': 'hi', 'Coréen': 'ko',
            'Néerlandais': 'nl', 'Suédois': 'sv', 'Polonais': 'pl', 'Turc': 'tr',
            'Catalan': 'ca', 'Ukrainien': 'uk', 'Tchèque': 'cs', 'Hongrois': 'hu'
        }
        self.language_names = {v: k for k, v in self.languages.items()}
        self.tts_models = {
            "fr": "tts_models/fr/css10/vits",
            "en": "tts_models/en/ljspeech/tacotron2-DDC",
            "es": "tts_models/es/css10/vits",
            "de": "tts_models/de/css10/vits",
            "it": "tts_models/it/mai_female/vits",
            "pt": "tts_models/pt/cv/vits"
        }

    def split_audio_segments(self, video_path, segment_length=30):
        with VideoFileClip(video_path) as video:
            duration = video.duration
            segments = []
            for start in range(0, int(duration), segment_length):
                end = min(start + segment_length, duration)
                if end - start > 5:
                    segment_clip = video.subclip(start, end)
                    segments.append({
                        'start': start,
                        'end': end,
                        'clip': segment_clip,
                        'duration': end - start
                    })
        return segments

    def transcribe_segment_with_language(self, segment_clip, model):
        with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as temp_audio:
            segment_clip.audio.write_audiofile(temp_audio.name, codec='pcm_s16le', verbose=False, logger=None)
            try:
                result = model.transcribe(temp_audio.name, fp16=False)
                text = (result.get("text") or "").strip()
                if text and len(text) > 10:
                    try:
                        detected_lang = detect(text)
                    except LangDetectError:
                        detected_lang = result.get("language", "unknown")
                    return text, detected_lang
            except Exception as e:
                st.warning(f"Erreur de transcription: {e}")
                return None, None
            finally:
                if os.path.exists(temp_audio.name):
                    os.unlink(temp_audio.name)
        return None, None

    def analyze_multilingual_video(self, video_path, progress_callback=None):
        model = get_whisper_model()
        if progress_callback: progress_callback("Division de la vidéo en segments...", 10)
        segments = self.split_audio_segments(video_path)
        results, detected_languages = [], set()

        for i, segment in enumerate(segments):
            if progress_callback:
                progress = 10 + int((i / max(1, len(segments))) * 70)
                progress_callback(f"Analyse du segment {i+1}/{len(segments)}...", progress)

            text, lang = self.transcribe_segment_with_language(segment['clip'], model)
            if text and lang:
                detected_languages.add(lang)
                lang_name = self.language_names.get(lang, lang)
                results.append({
                    'speaker': None,  # no diarization in this path
                    'segment': i + 1,
                    'start_time': str(timedelta(seconds=int(segment['start']))),
                    'end_time': str(timedelta(seconds=int(segment['end']))),
                    'start_seconds': segment['start'],
                    'end_seconds': segment['end'],
                    'duration': segment['duration'],
                    'original_language': lang,
                    'language_name': lang_name,
                    'original_text': text,
                    'translated_text': None
                })

        if progress_callback: progress_callback("Analyse terminée!", 100)
        return results, detected_languages

processor = MultilingualVideoProcessor()

# ==============================================================================
# 4. HELPERS (DOWNLOAD, TRANSLATION, TTS, AUDIO)
# ==============================================================================
@st.cache_data
def download_youtube_video(youtube_url):
    temp_dir = tempfile.mkdtemp()
    output_path = os.path.join(temp_dir, 'video.%(ext)s')
    ydl_opts = {
        'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best',
        'outtmpl': output_path,
        'merge_output_format': 'mp4',
        'quiet': True
    }
    with YoutubeDL(ydl_opts) as ydl:
        info_dict = ydl.extract_info(youtube_url, download=True)
        downloaded_file = ydl.prepare_filename(info_dict)
        if not downloaded_file.endswith('.mp4'):
            base, _ = os.path.splitext(downloaded_file)
            downloaded_file = base + '.mp4'
        return downloaded_file, info_dict.get('title', 'Vidéo YouTube')

def translate_text_gemini(text, src_lang="auto", tgt_lang="en"):
    if not text: return text
    if src_lang == tgt_lang: return text
    prompt = f"""
    Traduis ce texte de '{src_lang}' vers '{tgt_lang}' de manière fluide et naturelle.
    Conserve le style et le ton original.

    Texte à traduire :
    {text}

    Traduction :
    """
    try:
        response = model_gemini.generate_content(prompt)
        return response.text
    except Exception as e:
        st.error(f"Erreur de traduction: {e}")
        return text

def generate_audio_multilingual(segments_data, target_language, output_path):
    lang_map = {"fr": "fr-FR", "en": "en-US", "es": "es-ES", "de": "de-DE"}
    fallback = processor.tts_models.get(target_language, "tts_models/en/ljspeech/tacotron2-DDC")
    model_name = processor.tts_models.get(target_language) or fallback
    try:
        # Cache TTS instance per language
        if 'tts_model' not in st.session_state or st.session_state.tts_lang != target_language:
            st.session_state.tts_model = TTS(model_name)
            st.session_state.tts_lang = target_language
        tts = st.session_state.tts_model
        full_text = " ".join([s['translated_text'] or "" for s in segments_data if s.get('translated_text')])
        if not full_text.strip():
            raise Exception("Aucun texte traduit disponible")
        tts.tts_to_file(text=full_text, file_path=output_path)
    except Exception as e:
        st.error(f"Erreur TTS pour la langue {target_language}: {e}")
        raise

def replace_audio_in_video(video_path, audio_path, output_path):
    with VideoFileClip(video_path) as video, AudioFileClip(audio_path) as new_audio:
        final_video = video.set_audio(new_audio)
        final_video.write_videofile(output_path, codec="libx264", audio_codec="aac", verbose=False, logger=None)

def extract_full_audio_wav(video_path) -> str:
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".wav")
    tmp.close()
    with VideoFileClip(video_path) as clip:
        clip.audio.write_audiofile(tmp.name, fps=16000, nbytes=2, codec='pcm_s16le', verbose=False, logger=None)
    return tmp.name

# ==============================================================================
# 5. DIARIZATION + TRANSCRIPTION PER SPEAKER
# ==============================================================================
def analyze_speakers_multilingual(video_path, progress_callback=None):
    if not HF_TOKEN:
        st.error("HUGGINGFACE_TOKEN manquant : impossible d'activer la diarisation.")
        return [], set(), []

    whisper_model = get_whisper_model()
    diar_pipeline = get_diarization_pipeline(HF_TOKEN)

    if progress_callback: progress_callback("🎧 Extraction audio…", 5)
    wav_path = extract_full_audio_wav(video_path)

    if progress_callback: progress_callback("🗣️ Détection des locuteurs…", 15)
    diarization = diar_pipeline(wav_path)

    # Load audio to cut segments quickly
    y, sr = librosa.load(wav_path, sr=16000, mono=True)
    if os.path.exists(wav_path): os.unlink(wav_path)

    turns = []
    for speech_turn in diarization.itertracks(yield_label=True):
        (segment, speaker) = speech_turn
        start_s = max(0.0, float(segment.start))
        end_s = float(segment.end)
        if end_s - start_s >= 0.5:
            turns.append((start_s, end_s, speaker))

    results, detected_languages, speakers = [], set(), []
    total = len(turns)

    for i, (start_s, end_s, speaker) in enumerate(turns, start=1):
        if progress_callback:
            progress = 15 + int((i / max(1, total)) * 70)
            progress_callback(f"📝 Transcription tour {i}/{total} ({speaker})…", progress)

        with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as seg_wav:
            seg_wav_path = seg_wav.name
        start_idx = int(start_s * sr)
        end_idx = int(end_s * sr)
        seg = y[start_idx:end_idx]
        sf.write(seg_wav_path, seg, sr)

        try:
            wres = whisper_model.transcribe(seg_wav_path, fp16=False)
            text = (wres.get("text") or "").strip()
            lang = wres.get("language", None)
            if text and len(text) > 2:
                try:
                    lang2 = detect(text)
                    if lang2: lang = lang2
                except LangDetectError:
                    pass

                detected_languages.add(lang or "unknown")
                results.append({
                    'speaker': speaker,
                    'segment': len(results) + 1,
                    'start_time': str(timedelta(seconds=int(start_s))),
                    'end_time': str(timedelta(seconds=int(end_s))),
                    'start_seconds': float(start_s),
                    'end_seconds': float(end_s),
                    'duration': float(end_s - start_s),
                    'original_language': lang or "unknown",
                    'language_name': processor.language_names.get(lang, lang),
                    'original_text': text,
                    'translated_text': None
                })
                speakers.append(speaker)
        finally:
            if os.path.exists(seg_wav_path):
                os.unlink(seg_wav_path)

    if progress_callback: progress_callback("✅ Diarisation + transcription terminées", 100)
    return results, detected_languages, sorted(list(set(speakers)))

# ==============================================================================
# 6. VISUALIZATIONS
# ==============================================================================
def create_language_timeline(results):
    if not results: return None
    df = pd.DataFrame(results)
    fig = px.timeline(
        df,
        x_start="start_seconds",
        x_end="end_seconds",
        y="language_name",
        color="language_name",
        title="Timeline des langues détectées",
        labels={"start_seconds":"Temps (secondes)", "language_name":"Langue"}
    )
    fig.update_layout(height=400, xaxis_title="Temps (secondes)")
    return fig

def create_language_distribution(results):
    if not results: return None
    language_durations = {}
    for r in results:
        lang = r['language_name']
        language_durations[lang] = language_durations.get(lang, 0) + r['duration']
    if not language_durations: return None
    df = pd.DataFrame({"Langue": list(language_durations.keys()),
                       "Durée": list(language_durations.values())})
    fig = px.pie(df, values="Durée", names="Langue", title="Répartition du temps par langue")
    fig.update_layout(height=400)
    return fig

def create_speaker_timeline(results):
    if not results: return None
    df = pd.DataFrame(results)
    if "speaker" not in df.columns: return None
    fig = px.timeline(
        df,
        x_start="start_seconds",
        x_end="end_seconds",
        y="speaker",
        color="speaker",
        title="Timeline par locuteur (qui parle quand)",
        labels={"start_seconds":"Temps (secondes)", "speaker":"Locuteur"}
    )
    fig.update_layout(height=400, xaxis_title="Temps (secondes)")
    return fig

# ==============================================================================
# 7. CHATBOT
# ==============================================================================
def chatbot_answer(question: str) -> str:
    if not question or not question.strip():
        return "Veuillez poser une question pertinente."

    context = ""
    if "multilingual_results" in st.session_state and st.session_state.multilingual_results:
        segs = []
        for r in st.session_state.multilingual_results:
            who = f"{r.get('speaker')} - " if r.get('speaker') else ""
            segs.append(f"{who}Segment {r['segment']} ({r['start_time']}-{r['end_time']}) [{r['language_name']}]: {r['original_text']}")
        detected = st.session_state.detected_languages if "detected_languages" in st.session_state else set()
        context = f"Tu es un assistant expert analysant une vidéo multilingue et multi-locuteurs.\nSegments:\n" + "\n".join(segs) + f"\n\nLangues détectées: {', '.join(detected)}"
    elif "transcribed_text" in st.session_state and st.session_state.transcribed_text:
        context = f"Tu es un assistant expert dont l'unique rôle est de répondre aux questions concernant le texte suivant:\n---\n{st.session_state.transcribed_text}\n---"
    else:
        context = """Tu es un assistant virtuel expert pour une application de traduction vidéo multilingue.
Fonctionnalités :
- Upload vidéo / lien YouTube
- Détection de langues multiples & diarisation
- Traduction vers 20+ langues
- Synthèse vocale & vidéo finale
- Graphiques & exports"""

    full_prompt = f"{context}\n\nQuestion de l'utilisateur : \"{question}\"\n\nTa réponse :"
    try:
        response = model_gemini.generate_content(full_prompt)
        return response.text
    except Exception as e:
        st.error(f"Erreur de communication avec l'IA : {e}")
        return "Désolé, une erreur est survenue. Veuillez réessayer."

# ==============================================================================
# 8. UI
# ==============================================================================
st.markdown("<h1 style='text-align:center;'>🎬 Traducteur Vidéo IA Multilingue</h1>", unsafe_allow_html=True)
st.markdown("<p style='text-align:center;'>Détection automatique multi-langues, diarisation (plusieurs personnes) et traduction intelligente</p>", unsafe_allow_html=True)

tab1, tab2, tab3 = st.tabs(["🎥 Traduction", "📊 Analyse", "📋 Résultats"])

with tab1:
    with st.container():
        uploaded_video = st.file_uploader("📁 Choisissez un fichier vidéo", type=["mp4", "mkv", "avi"])
        st.markdown("<p style='text-align:center;'>OU</p>", unsafe_allow_html=True)
        video_url = st.text_input("📺 Entrez une URL YouTube", placeholder="https://www.youtube.com/watch?v=...")

    with st.container():
        col1, col2, col3 = st.columns(3)
        with col1:
            analysis_mode = st.selectbox(
                "Mode d'analyse",
                ["Auto-détection multilingue", "Langue unique spécifiée"],
                help="Auto-détection: détecte la langue segment par segment"
            )
            diarization_on = st.checkbox(
                "Activer la diarisation (plusieurs personnes)",
                value=True if HF_TOKEN else False,
                help="Identifie les locuteurs (Speaker 00, 01, …) et attribue les segments."
            )
            if diarization_on and not HF_TOKEN:
                st.warning("⚠️ HUGGINGFACE_TOKEN manquant (.env). La diarisation sera ignorée.")
        with col2:
            if analysis_mode == "Langue unique spécifiée":
                src_lang = st.selectbox("Langue d'origine", list(processor.languages.keys()))
            else:
                src_lang = "auto"
        with col3:
            tgt_lang_name = st.selectbox("Langue cible", list(processor.languages.keys()))
            tgt_lang = processor.languages[tgt_lang_name]

        output_option = st.radio(
            "Format de sortie",
            ["Analyse seulement", "Vidéo traduite (MP4)", "Audio seulement (MP3)", "Vidéo et Audio"],
            horizontal=True
        )

    if st.button("🚀 Lancer l'analyse", type="primary", use_container_width=True):
        for key in ["transcribed_text", "multilingual_results", "detected_languages", "video_title", "speakers"]:
            if key in st.session_state: del st.session_state[key]

        if not uploaded_video and not video_url:
            st.error("Veuillez uploader une vidéo ou fournir un lien YouTube.")
        else:
            temp_video_path = None
            try:
                if uploaded_video:
                    with tempfile.NamedTemporaryFile(delete=False, suffix=".mp4") as temp_video:
                        temp_video.write(uploaded_video.read())
                        temp_video_path = temp_video.name
                        video_title = uploaded_video.name
                elif video_url:
                    with st.spinner("📥 Téléchargement de la vidéo YouTube..."):
                        temp_video_path, video_title = download_youtube_video(video_url)

                if temp_video_path and os.path.exists(temp_video_path):
                    progress_bar = st.progress(0)
                    status_text = st.empty()
                    def update_progress(message, progress):
                        status_text.text(message)
                        progress_bar.progress(progress)

                    if diarization_on and HF_TOKEN:
                        st.info("🗣️ Mode diarisation activé — attribution des segments par locuteur")
                        results, detected_languages, speakers = analyze_speakers_multilingual(temp_video_path, update_progress)
                        st.session_state.multilingual_results = results
                        st.session_state.detected_languages = detected_languages
                        st.session_state.speakers = speakers
                        st.session_state.video_title = video_title

                        if results and any(r['original_language'] != tgt_lang for r in results):
                            update_progress("🌍 Traduction des segments (par locuteur)…", 85)
                            for r in results:
                                r['translated_text'] = (
                                    r['original_text'] if r['original_language'] == tgt_lang
                                    else translate_text_gemini(r['original_text'], r['original_language'], tgt_lang)
                                )
                        st.success(f"✅ {len(results)} segments détectés — Locuteurs: {', '.join(speakers) if speakers else 'N/A'}")
                    else:
                        # Fallback: tes modes d'analyse originaux
                        if analysis_mode == "Auto-détection multilingue":
                            st.info("🔍 Mode auto-détection activé - Analyse des langues par segments")
                            results, detected_languages = processor.analyze_multilingual_video(temp_video_path, update_progress)
                            st.session_state.multilingual_results = results
                            st.session_state.detected_languages = detected_languages
                            st.session_state.video_title = video_title

                            if results and any(r['original_language'] != tgt_lang for r in results):
                                update_progress("🌍 Traduction des segments...", 80)
                                for r in results:
                                    r['translated_text'] = (
                                        r['original_text'] if r['original_language'] == tgt_lang
                                        else translate_text_gemini(r['original_text'], r['original_language'], tgt_lang)
                                    )
                            st.success(f"✅ Analyse terminée ! {len(detected_languages)} langues détectées dans {len(results)} segments")
                        else:
                            update_progress("🔍 Transcription standard...", 50)
                            model = get_whisper_model()
                            with VideoFileClip(temp_video_path) as clip:
                                with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as temp_audio:
                                    clip.audio.write_audiofile(temp_audio.name, codec='pcm_s16le', verbose=False, logger=None)
                                    result = model.transcribe(temp_audio.name, fp16=False)
                            if os.path.exists(temp_audio.name): os.unlink(temp_audio.name)
                            transcription = result.get("text", "")
                            st.session_state.transcribed_text = transcription
                            st.session_state.video_title = video_title
                            update_progress("✅ Transcription terminée!", 100)

                    progress_bar.empty()
                    status_text.empty()

                    # Output generation
                    if output_option != "Analyse seulement" and "multilingual_results" in st.session_state:
                        if st.session_state.multilingual_results:
                            with st.spinner("🎙️ Génération audio..."):
                                with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as temp_audio_out:
                                    generate_audio_multilingual(st.session_state.multilingual_results, tgt_lang, temp_audio_out.name)

                                    if "Vidéo" in output_option:
                                        with st.spinner("🎬 Création de la vidéo finale..."):
                                            with tempfile.NamedTemporaryFile(delete=False, suffix=".mp4") as temp_video_out:
                                                replace_audio_in_video(temp_video_path, temp_audio_out.name, temp_video_out.name)
                                                st.success("✅ Vidéo multilingue traduite prête !")
                                                with open(temp_video_out.name, "rb") as f:
                                                    st.download_button("📥 Télécharger la vidéo (MP4)", f.read(), "video_multilingue_traduite.mp4", mime="video/mp4")

                                    if "Audio" in output_option:
                                        st.success("✅ Audio multilingue prêt !")
                                        with open(temp_audio_out.name, "rb") as f:
                                            st.download_button("🎧 Télécharger l'audio (MP3)", f.read(), "audio_multilingue_traduit.mp3", mime="audio/mp3")
                else:
                    st.error("Le chemin de la vidéo n'a pas pu être déterminé.")
            except Exception as e:
                st.error(f"Une erreur majeure est survenue : {e}")
            finally:
                if temp_video_path and os.path.exists(temp_video_path):
                    try: os.unlink(temp_video_path)
                    except: pass

with tab2:
    st.subheader("📊 Analyse")
    if "multilingual_results" in st.session_state and st.session_state.multilingual_results:
        results = st.session_state.multilingual_results
        detected_languages = st.session_state.get("detected_languages", set())
        video_title = st.session_state.get("video_title", "Vidéo analysée")

        c1, c2, c3, c4 = st.columns(4)
        with c1:
            st.metric("Titre", value="", delta=video_title[:30] + "..." if len(video_title) > 30 else video_title)
        with c2:
            total_duration = sum([r['duration'] for r in results])
            st.metric("Durée totale", f"{int(total_duration//60)}min {int(total_duration%60)}s")
        with c3:
            st.metric("Segments", len(results))
        with c4:
            st.metric("Langues", len(detected_languages))

        col1, col2 = st.columns(2)
        with col1:
            tl_lang = create_language_timeline(results)
            if tl_lang: st.plotly_chart(tl_lang, use_container_width=True)
        with col2:
            tl_speaker = create_speaker_timeline(results)
            if tl_speaker: st.plotly_chart(tl_speaker, use_container_width=True)

        dist = create_language_distribution(results)
        if dist: st.plotly_chart(dist, use_container_width=True)

        st.subheader("📋 Détail par langue")
        language_summary = {}
        for r in results:
            lang = r['language_name']
            language_summary.setdefault(lang, {"segments":0, "total_duration":0.0, "texts":[]})
            language_summary[lang]["segments"] += 1
            language_summary[lang]["total_duration"] += r['duration']
            language_summary[lang]["texts"].append(r['original_text'])
        for lang, s in language_summary.items():
            with st.expander(f"🗣️ {lang} ({s['segments']} segments, {int(s['total_duration'])}s)"):
                for i, text in enumerate(s['texts'][:3]):
                    st.write(f"**Extrait {i+1}:** {text[:200]}...")
                if len(s['texts']) > 3:
                    st.write(f"... et {len(s['texts'])-3} autres segments")
    else:
        st.info("Aucune analyse disponible. Lancez d'abord une analyse.")

with tab3:
    st.subheader("📋 Résultats détaillés")
    if "multilingual_results" in st.session_state and st.session_state.multilingual_results:
        results = st.session_state.multilingual_results
        col1, col2, col3 = st.columns(3)
        with col1:
            languages_found = sorted(list(set([r['language_name'] for r in results])))
            selected_languages = st.multiselect("Filtrer par langue:", options=languages_found, default=languages_found)
        with col2:
            speakers_found = sorted(list(set([r['speaker'] for r in results if r.get('speaker')])))
            if speakers_found:
                selected_speakers = st.multiselect("Filtrer par locuteur:", options=speakers_found, default=speakers_found)
            else:
                selected_speakers = []
        with col3:
            show_translations = st.checkbox("Afficher les traductions", value=True)

        def include_row(r):
            ok_lang = r['language_name'] in selected_languages
            if speakers_found:
                ok_spk = (r.get('speaker') in selected_speakers) if r.get('speaker') else False
            else:
                ok_spk = True
            return ok_lang and ok_spk

        filtered_results = [r for r in results if include_row(r)]

        for r in filtered_results:
            title = f"🎬 Segment {r['segment']} - {r['start_time']} à {r['end_time']} ({r['language_name']})"
            if r.get('speaker'): title = f"{r['speaker']} · {title}"
            with st.expander(title):
                c1, c2 = st.columns(2)
                with c1:
                    st.write("**Texte original:**")
                    st.write(r['original_text'])
                    st.write(f"**Langue:** {r['language_name']} (`{r['original_language']}`)")
                with c2:
                    if show_translations and r.get('translated_text'):
                        st.write(f"**Traduction ({tgt_lang_name}):**")
                        st.write(r['translated_text'])
                    else:
                        st.write("**Informations:**")
                        st.write(f"Durée: {r['duration']:.1f}s")
                        st.write(f"Position: {r['start_time']} - {r['end_time']}")

        st.subheader("💾 Export des données")
        c1, c2 = st.columns(2)
        with c1:
            export_data = {
                'video_info': {
                    'title': st.session_state.get("video_title", ""),
                    'analysis_date': datetime.now().isoformat(),
                    'total_segments': len(results),
                    'languages_detected': len(st.session_state.get("detected_languages", set())),
                    'detected_languages': list(st.session_state.get("detected_languages", set())),
                    'speakers': st.session_state.get("speakers", [])
                },
                'segments': results
            }
            st.download_button(
                label="📥 Télécharger JSON complet",
                data=json.dumps(export_data, indent=2, ensure_ascii=False),
                file_name=f"analyse_multilingue_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
                mime="application/json"
            )
        with c2:
            df = pd.DataFrame(results)
            st.download_button(
                label="📥 Télécharger CSV",
                data=df.to_csv(index=False),
                file_name=f"segments_multilingues_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                mime="text/csv"
            )
    elif "transcribed_text" in st.session_state:
        st.subheader("📝 Transcription complète")
        st.text_area("Texte transcrit:", st.session_state.transcribed_text, height=300)
    else:
        st.info("Aucun résultat disponible. Lancez d'abord une analyse.")

# ==============================================================================
# 9. SIDEBAR CHATBOT
# ==============================================================================
if "chatbot_visible" not in st.session_state:
    st.session_state.chatbot_visible = False

if not st.session_state.chatbot_visible:
    if st.sidebar.button("💬 Afficher chatbot IA", use_container_width=True):
        st.session_state.chatbot_visible = True
        st.rerun()

if st.session_state.chatbot_visible:
    st.sidebar.title("🤖 Assistant IA Multilingue")
    if st.sidebar.button("❌ Masquer Chatbot", use_container_width=True):
        st.session_state.chatbot_visible = False
        st.rerun()

    if "multilingual_results" in st.session_state and st.session_state.multilingual_results:
        st.sidebar.info("🌍 Mode: Expert analyse multilingue (diarisation si activée)")
        if st.sidebar.button("🔄 Mode assistant général"):
            for key in ["multilingual_results", "transcribed_text"]:
                if key in st.session_state: del st.session_state[key]
            st.session_state.messages = [{"role":"assistant","content":"Bonjour ! Comment puis-je vous aider avec l'application de traduction multilingue ?"}]
            st.rerun()
    elif "transcribed_text" in st.session_state and st.session_state.transcribed_text:
        st.sidebar.info("📝 Mode: Expert contenu vidéo")
        if st.sidebar.button("🔄 Mode assistant général"):
            del st.session_state.transcribed_text
            st.session_state.messages = [{"role":"assistant","content":"Bonjour ! Comment puis-je vous aider avec l'application de traduction multilingue ?"}]
            st.rerun()
    else:
        st.sidebar.info("ℹ️ Mode: Assistant général")

    if "messages" not in st.session_state:
        st.session_state.messages = [{"role":"assistant","content":"Bonjour ! Je suis votre assistant IA pour l'application de traduction vidéo multilingue. Comment puis-je vous aider ?"}]

    for message in st.session_state.messages:
        with st.sidebar.chat_message(message["role"]):
            st.markdown(message["content"])

    if user_question := st.sidebar.chat_input("Votre question..."):
        st.session_state.messages.append({"role": "user", "content": user_question})
        with st.sidebar.chat_message("user"):
            st.markdown(user_question)
        with st.sidebar.chat_message("assistant"):
            with st.spinner("🤔 Je réfléchis..."):
                response = chatbot_answer(user_question)
                st.markdown(response)
        st.session_state.messages.append({"role":"assistant","content":response})

# ==============================================================================
# 10. HELP / WELCOME
# ==============================================================================
with st.sidebar.expander("ℹ️ Aide et informations"):
    st.markdown("""
### 🎯 Fonctionnalités principales
**🔍 Auto-détection multilingue & 🗣️ Diarisation :**
- Détecte automatiquement les langues et *qui parle quand*
- Timeline par langue et par locuteur

**🌍 Traduction intelligente :**
- Support 20+ langues via Gemini
- Ton & style conservés

**🎙️ Synthèse vocale & 🎬 Vidéo finale :**
- Audio TTS natif par langue
- Remplacement de la piste audio

**📊 Analyse & 📤 Exports :**
- Graphiques, filtres, JSON/CSV
    """)

if "first_visit" not in st.session_state:
    st.session_state.first_visit = True
    st.info("""
🎉 **Bienvenue !**
- Détecte plusieurs langues et plusieurs locuteurs (speaker diarization)
- Traduit et génère une nouvelle piste audio
- Visualise qui parle quand et les langues utilisées
    """)

st.sidebar.markdown("---")
st.sidebar.markdown("""
<div style='text-align:center;color:#666;font-size:12px;'>
    <p>🤖 Propulsé par Whisper • Gemini • Coqui TTS • pyannote.audio</p>
    <p>Version 2.1 — Diarisation par locuteur</p>
</div>
""", unsafe_allow_html=True)
