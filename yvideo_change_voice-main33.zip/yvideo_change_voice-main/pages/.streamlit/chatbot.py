import streamlit as st
from streamlit_javascript import st_javascript
import google.generativeai as genai
import os
from dotenv import load_dotenv

load_dotenv()
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
genai.configure(api_key=GEMINI_API_KEY)
model = genai.GenerativeModel("gemini-pro")

def chatbot_answer(question: str) -> str:
    if not question:
        return "Pose-moi ta question !"
    try:
        response = model.generate_content(question)
        return response.text if hasattr(response, "text") else str(response)
    except Exception as e:
        return f"Erreur Gemini : {e}"

user_question = st_javascript("""
    () => {
        window.chatbotSendToPython = (question) => {
            window.parent.postMessage({isStreamlitMessage: true, type: "streamlit:setComponentValue", value: question}, "*");
        };
        if (!window.__chatbot_injected) {
            window.__chatbot_injected = true;
            window.customQuestion = function() {
                const input = document.getElementById("userInput").value;
                window.chatbotSendToPython(input);
            }
        }
        return null;
    }
""")

if user_question:
    st.session_state["last_bot_answer"] = chatbot_answer(user_question)

last_bot_answer = st.session_state.get('last_bot_answer', '')

st.components.v1.html(f"""
<div style="max-width:400px;margin:30px auto;padding:24px;">
    <input type="text" id="userInput" placeholder="Pose ta question..." style="width:100%;padding:8px;">
    <button onclick="customQuestion()" style="width:100%;padding:10px;">Envoyer</button>
    <div id="chatbot-response" style="margin-top:18px;">{last_bot_answer}</div>
</div>
<script>
window.customQuestion = function() {{
    const input = document.getElementById("userInput").value;
    if (window.chatbotSendToPython) {{
        window.chatbotSendToPython(input);
    }} else {{
        document.getElementById("chatbot-response").innerHTML = "Erreur de connexion au module IA.";
    }}
}};
window.setInterval(() => {{
    let resp = "{last_bot_answer}";
    if(document.getElementById("chatbot-response") && resp && document.getElementById("chatbot-response").innerHTML !== resp) {{
        document.getElementById("chatbot-response").innerHTML = resp;
    }}
}}, 1000);
</script>
""", height=300)